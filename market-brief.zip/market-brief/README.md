# 市场速览 · AI 算力链

一个零服务器、零成本的个人行情看板。手机打开就能看到自选股涨跌、板块传导和当日新闻。

```
GitHub Actions(定时,免费)
   └─ fetch_market.py  抓行情 + 新闻 + 生成要点
        └─ data/market.json  提交回仓库
             └─ index.html   GitHub Pages 上的静态页读它
```

没有后端、没有数据库、不用租服务器。

---

## 一、先在本地跑通

```bash
pip install yfinance akshare requests
python fetch_market.py
```

跑完会生成 `data/market.json`。然后本地起个小服务看效果:

```bash
python -m http.server 8000
# 浏览器打开 http://localhost:8000
```

> 直接双击 `index.html` 打不出实盘数据 —— 浏览器不允许 `file://` 页面读本地 json,
> 会退回演示数据。必须用上面的 `http.server`,或者部署到 Pages 之后再看。

---

## 二、传到 GitHub

```bash
git init
git add .
git commit -m "初始版本"
git branch -M main
git remote add origin https://github.com/你的用户名/market-brief.git
git push -u origin main
```

## 三、开 GitHub Pages

仓库页面 → **Settings** → **Pages** → Source 选 `Deploy from a branch`,
分支选 `main` / 根目录 `/`,保存。

一两分钟后网址就有了:`https://你的用户名.github.io/market-brief/`

手机 Safari 打开 → 分享 → **添加到主屏幕**,图标点开就跟 App 一样。

## 四、让它自己更新

`.github/workflows/update.yml` 已经配好了,推上去就会按时跑。
第一次可以去 **Actions** 页面手动点一次 `Run workflow` 验证。

想要 AI 生成的「今日要点」:
**Settings → Secrets and variables → Actions → New repository secret**,
名字填 `ANTHROPIC_API_KEY`,值填你的 key。不填也能用,会退回规则版摘要。

---

## 改哪里

| 想改什么 | 改哪 |
|---|---|
| 加减自选股 | `fetch_market.py` 顶部的 `WATCHLIST` |
| 换新闻源 | `fetch_market.py` 的 `build_news()` |
| 改摘要口径 | `build_highlights()` 里的 prompt |
| 改配色 / 排版 | `index.html` 顶部的 `:root` 变量 |
| 改更新时间 | `update.yml` 里的 cron(**UTC 时间**) |

## 数据源说明

| 市场 | 库 | 是否要 key | 延迟 |
|---|---|---|---|
| 美股 | yfinance | 否 | 约 15 分钟 |
| 港股 | yfinance | 否 | 约 15 分钟 |
| A 股 | akshare | 否 | 收盘价为准 |
| 新闻 | akshare(财联社电报) | 否 | 近实时 |

**关于「实时」**:上面这些都是延迟或收盘数据。真正的逐笔实时行情基本都要付费
(Polygon、Databento、万得、同花顺 iFinD 之类)。对开盘前扫一眼、盘后复盘的用途,
延迟数据完全够;要做日内交易才需要升级数据源。

想换更规整的美股新闻源,可以注册 [Finnhub](https://finnhub.io) 免费档,
把 `build_news()` 换成调它的 `/company-news` 接口,能按公司精确过滤。

## 已知限制

- Actions 的 cron 在免费额度下会有几分钟到十几分钟延迟,不保证准点
- 仓库连续 60 天没有人工提交,GitHub 会自动暂停定时任务(去 Actions 页面点一下恢复)
- akshare 依赖的是各家网站的公开接口,对方改版时可能需要升级 akshare 版本
